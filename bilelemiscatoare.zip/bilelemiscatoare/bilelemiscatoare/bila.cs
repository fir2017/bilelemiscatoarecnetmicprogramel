﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace bilelemiscatoare
{
    public partial class bila : UserControl
    {
        public bila()
        {
            InitializeComponent();
        }
        public int directionx = 1;
        public int directiony = 1;

        private void bila_Load(object sender, EventArgs e)
        {

        }
    }
}
